<?php 

namespace App\Interfaces\Invoice;


Interface InvoiceMaintenanceInterface
{
    public function createInvoiceMaintenance($request);
}