<?php 

namespace App\Interfaces\DailyReport;


interface DailyReportInterface{
    public function getInvoicesAndIncomesAndExpensesDaily();
}