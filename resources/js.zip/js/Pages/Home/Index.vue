<template>
    <div>
        <h1>mazin</h1>
    </div>
</template>

<script>
import Layout from "../shared/layout";
export default {
    layout: Layout,
};
</script>
