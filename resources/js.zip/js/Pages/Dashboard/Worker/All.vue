<template>
  <div>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Debitis exercitationem maiores eos dignissimos, laudantium sunt consectetur commodi quis, eum corporis quas eligendi corrupti illo aperiam amet facilis repellendus facere. Corrupti!
  </div>
</template>

<script>
    import Layout from "../../shared/layout";
export default {
    layout: Layout,
    props:['workers']
}
</script>

<style>

</style>