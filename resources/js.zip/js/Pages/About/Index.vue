<template>
    <div>hddh</div>
</template>

<script>
import Layout from "../shared/layout";
export default {
    layout: Layout,
};
</script>
