<div class="d-flex" style="justify-content: center;">
    {!! $paginator->links() !!}
  </div>